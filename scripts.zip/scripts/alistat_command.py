~/AliStat/alistat input_file.fasta > output_summary.txt

where the arguments are as follows:
input_file.fasta → Input FASTA file containing alignment to be evaluated.
output_summary.txt
  → Output summary file.
