from Bio import SeqIO
# === Step 1: Extract IDs from Cluster no ===
cluster_file = "Protein_name.txt.clstr"
cluster_number = "Cluster no"
ids = set()
with open(cluster_file) as f:
    in_cluster = False
    for line in f:
        line = line.strip()
        if line.startswith(">Cluster"):
            in_cluster = (line == f">{cluster_number}")
        elif in_cluster and ">" in line:
            try:
                seq_id = line.split(">")[1].split("...")[0]
                ids.add(seq_id)
            except IndexError:
                continue

# === Step 2: Extract sequences from FASTA file ===
input_fasta = "protein name.txt"
output_fasta = "cluster_sequences.fasta"

count = 0
with open(output_fasta, "w") as out_handle:
    for record in SeqIO.parse(input_fasta, "fasta"):
        fasta_id = record.id.split()[0]
        if fasta_id in ids:
            SeqIO.write(record, out_handle, "fasta")
            count += 1
print(f" Extracted {count} sequences from Cluster no  to '{output_fasta}’"
