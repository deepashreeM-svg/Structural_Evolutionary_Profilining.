import os
meg_files_folder= '/home/meg_files'
meg_files = [f for f in os.listdir(meg_files_folder) if f.endswith('.meg')]
for meg_file in meg_files:
        with open(f"{meg_file.split('.')[0]}_labels.txt", 'w') as metadata_file:
            meg_file = os.path.join(meg_files_folder, meg_file)
            metadata_file.write(""" LABELS
#use this template to change the leaf labels, or define/change the internal node names (displayed in mouseover popups)
#lines starting with a hash are comments and ignored during parsing
#=================================================================#
#                    MANDATORY SETTINGS                           #
#=================================================================#
#select the separator which is used to delimit the data below (TAB,SPACE or COMMA).This separator must be used throughout this file (except in the SEPARATOR line, which uses space).
SEPARATOR TAB
#SEPARATOR SPACE
#SEPARATOR COMMA
#Internal tree nodes can be specified using IDs directly, or using the 'last common ancestor' method described in iTOL help pages
#=================================================================#
#       Actual data follows after the "DATA" keyword              #
#=================================================================#
DATA
#NODE_ID,LABEL""")
            metadata_file.write("\n")
            with open(meg_file, 'r') as f:          
                for ln in f.readlines():
                    if ln.startswith("#") and "_" in ln:
                        # print(f"Processing line: {ln.strip()}")
                        ln = ln.strip().replace('#', '')
                        accession_id = ln.strip().split('"')[0][:-1]
                        label_text = ln.strip().split('"')[1]

                        protein = label_text.split('[')[0][:-1]
                       if 'hypothetical' in protein or 'uncharacterized' in protein or 'unnamed_protein_product' in protein:
                            protein = 'unannotated'
                        organism = label_text.split('[')[1].split(']')[0]
                        final_label = f"{accession_id}_{protein}_{organism}".replace("PREDICTED:","PREDICTED")

                        # print(f"Accession ID: {accession_id}, Protein: {protein}, Organism: {organism}")                      metadata_file.write(f"{accession_id}\t{final_label}\n")
