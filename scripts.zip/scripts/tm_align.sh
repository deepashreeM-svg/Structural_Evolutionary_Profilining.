#!/bin/bash

mkdir -p results  # make sure results folder exists
cd inputs || { echo "inputs folder not found!"; exit 1; }

files=(*.pdb)

for ((i = 0; i < ${#files[@]}; i++)); do
    for ((j = i + 1; j < ${#files[@]}; j++)); do
        file1="${files[$i]}"
        file2="${files[$j]}"
        echo "Aligning $file1 vs $file2 ..."
        ../TMalign "$file1" "$file2" > "../results/${file1%.pdb}_${file2%.pdb}.txt"
    done
done

echo "All alignments complete. Check the 'results' folder."
