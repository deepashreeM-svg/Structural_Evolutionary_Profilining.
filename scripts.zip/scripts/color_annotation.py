from Bio import SeqIO
from collections import defaultdict
from matplotlib import cm
from matplotlib.colors import to_hex
import sys
# ----------
# INPUT
# ----------
genpept_file =  sys.argv[1] if len(sys.argv) > 1 else print("Usage: python get_color_annotation.py <genpept_file>")

if not genpept_file.endswith('.gb'):
    raise ValueError("The input file must be a GenBank file with a .gb extension.")

# Parsing the GenBank file to extract accession IDs and taxonomy

itol_annotation_file = genpept_file.replace('.gb', '_itol_annotation.txt')
accession_ids_list = []
taxonomy_list = []
for record in SeqIO.parse(genpept_file, "genbank"):
    accession_ids_list.append(record.id)
    # record.annotations['taxonomy'] is already a list of ranks:
    taxonomy_list.append(record.annotations.get('taxonomy', []))
assert len(accession_ids_list) == len(taxonomy_list)
taxonomy_dict = dict(zip(accession_ids_list, taxonomy_list))
print(len(taxonomy_dict.keys()))
# Generating the iTOL annotation file with colors based on 2nd-level taxonomy
# 1. Collect all unique 2nd-level taxa
second_levels = sorted({tax[1] for tax in taxonomy_dict.values() if len(tax) > 1})
# 2. Generate distinct colors for each 2nd-level group using a colormap
cmap = cm.get_cmap('tab20', len(second_levels))
color_map = {lvl: to_hex(cmap(i)) for i, lvl in enumerate(second_levels)}
# 3. Write the iTOL annotation file
output_file = 'itol_annotation.txt'
with open(output_file, 'w') as out:
    out.write("TREE_COLORS\nSEPARATOR TAB\nDATA\n")
    for acc, tax in taxonomy_dict.items():
        if len(tax) > 1:
            lvl = tax[1]
            color = color_map[lvl]
            out.write(f"{acc}\trange\t{color}\t{lvl}\n")

print(f"Annotation file written to: {output_file}")
