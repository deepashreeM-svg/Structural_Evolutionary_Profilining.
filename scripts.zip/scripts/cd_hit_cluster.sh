cd-hit -i input.fasta -o output.fasta -c 0.9 -n 5 



 where the arguments are as follows:
-i input.fasta → Input FASTA file containing protein sequences
-o output.fasta → Output file for representative sequences
-c 0.9 → Sequence identity threshold (90%)
-n 5 → Word length (default for 90% identity)
